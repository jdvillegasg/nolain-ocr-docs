# Reuse Auth and Stripe

This guide is split into focused instruction files:

1. [Project structure and files to copy](reuse-auth-stripe/copy-and-adapt.md)
2. [Configure Supabase and Google](reuse-auth-stripe/supabase-google.md)
3. [Configure Stripe](reuse-auth-stripe/stripe.md)
4. [Optional one-time credits](reuse-auth-stripe/one-time-credits.md)
5. [Test the integration](reuse-auth-stripe/testing.md)

Use a **new Supabase project and Stripe account/project** for the new app. Do not copy API keys, webhook secrets, customer IDs, product IDs, or Price IDs from this project.

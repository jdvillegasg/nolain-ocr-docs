# Optional: Add One-Time Credits

Follow these instructions only if the new product sells prepaid credits.

Copy:

```text
backend/api/api_v1/endpoints/topup_billing.py
backend/sql/create_api_credit_purchases_table.sql
scripts/setup_stripe_api_topups.py
```

Rename the Stripe product, pack labels, and `pages` fields to the new credit unit.

If the new product does not sell prepaid credits, do not copy these files.

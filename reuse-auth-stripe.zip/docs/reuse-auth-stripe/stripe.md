# Configure Stripe

## Configure the Stripe Dashboard

1. Start in **Test mode**.
2. Create one Product and one **recurring monthly Price** for each new plan.
3. Copy each new `price_...` ID. Test and Live modes use different Price IDs.
4. Activate and configure the Customer Portal if users should cancel or change plans.
5. Create a webhook endpoint:

   ```text
   https://YOUR-DOMAIN/api/webhook
   ```

6. Select these events:

   ```text
   checkout.session.completed
   customer.subscription.created
   customer.subscription.updated
   customer.subscription.deleted
   invoice.payment_succeeded
   ```

7. Copy the endpoint's `whsec_...` signing secret. Test and Live modes use different webhook secrets.

## Configure the application environment

Set new Stripe values for the application:

```env
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_STARTER_PRICE_ID=price_...
STRIPE_PRO_PRICE_ID=price_...
FRONTEND_URL=http://localhost:5173
```

Update `backend/core/config.py`, `backend/services/payment_service.py`, and `frontend/src/pages/AccountPage.tsx` to use the same plan names and Price IDs.

Do not reuse this project's Stripe secret key, webhook secret, customer IDs, Product IDs, or Price IDs.

# Configure Supabase and Google Authentication

1. Create a new Supabase project.
2. Add its credentials to the new application:

   ```env
   SUPABASE_URL=...
   SUPABASE_ANON_KEY=...
   SUPABASE_SERVICE_ROLE_KEY=...
   VITE_SUPABASE_URL=...
   VITE_SUPABASE_ANON_KEY=...
   ```

3. In Supabase Auth, enable the Email and Google providers.
4. Add these redirect URLs:

   ```text
   http://localhost:5173/auth/callback
   https://YOUR-DOMAIN/auth/callback
   ```

5. Run the adapted `backend/sql/create_subscriptions_table.sql` file.

Do not reuse any Supabase URL, API key, or service-role key from this project.

# Copy and Adapt the Auth and Billing Code

## Keep or adapt the folder structure

The copy instructions assume this structure so imports work without changes:

```text
frontend/src/{components,lib,pages,stores,types}
backend/{api,core,schemas,services}
```

- Keep this structure: copy the listed files without changing their import paths.
- Use a different structure: update every frontend `@/...` import and configure `@` to point to the new frontend source folder. Update Python imports such as `from backend.services...` to match the new backend folders.

## Copy the frontend authentication files unchanged

Copy:

```text
frontend/src/lib/supabase.ts
frontend/src/pages/AuthCallbackPage.tsx
frontend/src/components/auth/LoginForm.tsx
frontend/src/components/auth/RegisterForm.tsx
frontend/src/pages/PasswordResetPage.tsx
frontend/src/pages/PasswordResetConfirmPage.tsx
frontend/src/pages/EmailVerificationPage.tsx
frontend/src/components/ui/{button,input,card,password-input}.tsx
```

Copy these routes from `frontend/src/router.tsx`:

```text
/login, /register, /verify-email, /forgot-password, /reset-password, /auth/callback
```

Copy the backend route wiring:

```text
backend/api/api_v1/endpoints/auth.py
backend/api/api_v1/endpoints/payments.py
```

## Adapt the copied files

| File | Required change |
|---|---|
| `frontend/src/stores/authStore.ts` | Delete the `dashboardStore` import and `useDashboardStore.getState().resetDashboard()` in `logout`. |
| `frontend/src/lib/api.ts` | Retain only login, register, logout, password reset, Checkout, subscription, and billing-portal methods. Delete document, extraction, and export code. |
| `backend/services/auth_service.py` | In `logout`, delete `cleanup_user_files(user_id)` and its import. |
| `backend/api/api_v1/dependencies/auth.py` | Delete the `x_user_id` fallback; protected routes must validate `x_access_token`. |
| `backend/services/payment_service.py` | Replace every `pro`/`pro_plus` tier and Price ID comparison with the new plans. Remove page-quota and top-up methods if the product does not sell credits. Keep Checkout, webhook validation, Customer Portal, cancel, and plan-change methods. |
| `backend/core/config.py` | Replace the default Stripe Price IDs and plan/page-limit variables. Add one `STRIPE_<PLAN>_PRICE_ID` setting for each new recurring plan. |
| `backend/sql/create_subscriptions_table.sql` | Keep the Stripe IDs, `status`, `plan_tier`, and billing-period fields. Remove `total_pages_processed` when the product has no usage quota. |
| `frontend/src/pages/AccountPage.tsx` | Replace plan names, prices, and `PRO_PRICE_ID` / `PRO_PLUS_PRICE_ID`. Remove top-up and page-credit UI unless the new product needs it. |

Do not copy OCR document endpoints, `page_billing_service.py`, or dashboard state.

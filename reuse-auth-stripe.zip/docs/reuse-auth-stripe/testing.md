# Test the Auth and Stripe Integration

Before switching Stripe to Live mode, test:

1. Email registration.
2. Google sign-in.
3. Password reset.
4. Subscription Checkout.
5. Customer Portal access.
6. Subscription cancellation.
7. Webhook delivery.
